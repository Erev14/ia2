import numpy as np
from MLP import *
from DelayBlock import *

class NARX:
    #...
    #Non linear AutoRegressor with eXogeneous inputs.
    
    #Con red neuronal densa multicapa como funcion no lineal
    #...
    
    def __init__(self, n_inputs, n_outputs, n_delays,
                 dense_hidden_layers=(100,),
                 learning_rate=0.01,
                 n_repeat_train=5):
        
        self.net = MLP(((n_inputs+n_outputs)*n_delays,
                        *dense_hidden_layers, n_outputs),
                       output_activation='linear')
        
        self.dbx = DelayBlock(n_inputs, n_delays)
        self.dby = DelayBlock(n_outputs, n_delays)
        self.learning_rate = learning_rate
        self.n_repeat_train = n_repeat_train
        
    def predict(self, x):
        #Prediccion NARX
        #x es un vector de tamaño (n_inputs,1)
        
        #Preparar entrada extendida en el tiempo
        X_block = self.dbx.add_and_get(x)
        Y_est_block = self.dby.get()
        net_input = np.vstack((X_block, Y_est_block))
        
        #Prediccion de la red neuronal
        y_est = self.net.predict(net_input)
        
        #Guardar prediccion en el bloque recurrente
        self.dby.add(y_est)
        
        #Retornar prediccion
        return y_est
    
    def predict_and_train(self, x, y):
        #Prediccion y entrenamiento en linea de NARX
        #x es la entrada un vector de tamaño (n_inputs,1)
        #y es la salida deseada un vector de tamaño (n_outputs,1)
        
        #La prediccion se entrega antes del entrenamiento pero no se guarda
        #hasta despues de entrenar
        
        X_block = self.dbx.add_and_get(x)
        Y_est_block = self.dby.get()
        net_input = np.vstack((X_block, Y_est_block))
        
        #Prediccion de la red neuronal
        y_est = self.net.predict(net_input)
        
        #Entrenar red neuronal
        self.net.fit(net_input, y, 
                       epochs=self.n_repeat_train,
                       learning_rate = self.learning_rate)
        
        #Guardar prediccion en el bloque recurrente
        self.dby.add(y_est)
        
        #Retornar prediccion
        return y_est
        
        
        
        
        