import numpy as np

class DelayBlock:
    def __init__(self, n_inputs, n_delays):
        self.memory = np.zeros((n_inputs, n_delays))
        
    def add(self, x):
        #Creo una copia profunda para evitar conflictos
        #con la señal original
        x_new = x.copy().reshape(1,-1)
        
        #Implementacion del retardo
        self.memory[:,1:] = self.memory[:,:-1]
        self.memory[:,0] = x_new
        
    def get(self):
        #Retornar la memoria como un solo vector
        return self.memory.reshape(-1, 1, order='F')
    
    def add_and_get(self, x):
        #Unificacion de las dos funcionalidades en una sola
        self.add(x)
        return self.memory.reshape(-1, 1, order='F')
    
#Test code ----------------------------------------------------
